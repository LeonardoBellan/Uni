# InertialDriver - KFC Clash

Progetto intermedio laboratorio di programmazione

## Membri del gruppo:

-   Bellan Leonardo
-   Gava Marco
-   Piovesan Francesco

## Descrizione delle attività

### Bellan Leonardo

1. Modificata la classe MyVector in modo tale che potesse memorizzare la classe Misura
2. Realizzazione dei metodi push_back() e pop_front() di InertialDriver con gestione circolare del buffer
3. Documentazione

### Franceso Piovesan

1. Creazione classe Misura che gestisce un array bidimensionale 17x6 in cui ogni elemento è un valore di tipo double. E’ utilizzata per memorizzare e manipolare le misure numeriche, con funzionalità come accesso dati, stampa e inserimento.
2. Documentazione

### Gava Marco

1. Realizzazione della classe InertialDriver.
2. Realizzazione del main per testare il funzionamento di InertialDriver.
3. Documentazione
