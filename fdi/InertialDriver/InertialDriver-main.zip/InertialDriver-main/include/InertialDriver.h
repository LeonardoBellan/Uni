#ifndef INERTIALDRIVER_H
#define INERTIALDRIVER_H

#include "MyVector.h"
#include "Misura.h"

class InertialDriver{
  private:
    int BUFFER_DIM = 20;     //Buffer max size
    MyVector buffer;    //Vettore che contiene BUFFER_DIM-1 misure
    int front;          //Indice dell'elemento più vecchio nel buffer
    int back;           //Indice in cui inserire i nuovi elementi del buffer
    int numero_misure;
  public:
    class EmptyBufferException{};

    InertialDriver();
    InertialDriver(const int buff_dim);

    /**
     * Inserisce la misura in input in fondo al buffer.
     * Se quest'ultimo è pieno, elimina la misura più vecchia.
     * 
     * @param[in] misura Array[17][6] che rappresenta la misurazione da inserire
     */
    void push_back(const double misura[17][6]);

    /**
     * Fornisce in output la misura più vecchia e la rimuove dal buffer.
     * 
     * @returns Array[17][6] che rappresenta la misura più vecchia
     */
    std::array<std::array<double,6>,17> pop_front();

    /**
     * Elimina tutti gli elementi presenti all'interno del buffer
     */
    void clear_buffer();

    /**
     * Ritorna la lettura di indice i della misura più recente 
     */
    std::array<double,6> get_reading(int i);

    /**
     * Operatore<<
     */
    friend std::ostream& operator<<(std::ostream& os, const InertialDriver& driver);
};

#endif
