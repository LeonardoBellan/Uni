#ifndef MISURA_H
#define MISURA_H

#include <iostream>
#include <string>
#include <sstream>
#include <array>

class Misura{
    private:
        std::array<std::array<double,6>,17> letture;    //array di array con 17 letture x 6 valori
    public:
        Misura(){}; //costruttore default
        Misura(const double[17][6]);    //Costruttore con array come input
        Misura(const Misura& m);        //Costruttore di copia
        Misura& operator=(const Misura& m);     //Copy operator
        Misura& operator=(Misura&& m);          //Move operator

        /**
         * Fornisce in output la misura 
         * @returns array[17][6] contenente le 17 letture
         */
        std::array<std::array<double,6>,17> get_misura() const;

        /**
         * Fornisce in output la lettura di indice i
         * @param i indice della lettura
         * @returns array[6] contenente in ordine i valori della lettura: yaw_v, yaw_a, pitch_v, pitch_a, roll_v, roll_a
         */
        std::array<double,6> get_lettura(int i) const;

        /**
         * Converte la misurazione in stringa
         * @returns rappresentazione in stringa della misura
         */
        std::string toString() const;
        friend std::ostream& operator<<(std::ostream& os, const Misura& m);  // operatore <<
        friend std::istream& operator>>(std::istream& is, Misura& m);    // operatore >>
};

#endif
