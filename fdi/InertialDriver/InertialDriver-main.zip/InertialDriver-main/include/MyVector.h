#ifndef MYVECTOR_H
#define MYVECTOR_H

#include <stdexcept>
#include "Misura.h"

class MyVector{
  public:
    //Constructors

    /**
     * Fill constructor
     * Construct a vector of size s
     * 
     * @param Initial size of the vector
     */
    MyVector(int s);
    //MyVector(initializer_list<Misura> lst);

    /**
     * Copy constructor
     * @param arg vector whose elements are copied
     */
    MyVector(const MyVector& arg);

    /**
     * Move constructor
     * @param a vector whose elements are moved
     */
    MyVector(MyVector&& a);

    //Destructor
    ~MyVector();

    //*********METHODS *******/
    /**
     * Returns the current number of elements inside the mevtor
     * @returns size of the vector
     */
    int size() const;

    MyVector& operator=(const MyVector& a);
    MyVector& operator=(MyVector&& a);
    
    const Misura& operator[](int i) const;
    Misura& operator[](int i);

    /**
     * Get the element at index i with boundary checking
     * @returns Element at index i
     */
    const Misura& at(int i) const;
    Misura& at(int i);

    /**
     * Inserts input element at the end of the vector; if vector capacity is not enough, allocates new space.
     * @param d Element to insert
     */
    void push_back(Misura d);

    /**
     * Removes the element at the end of the vector
     */
    void pop_back();

    /**
     * Requests that the vector capacity be at least enough to contain n elements.
     * @param n Minimum capacity for the vector
     */
    void reserve(int n);
  private:
    int v_size;     //Number of elements inside the vector
    int capacity;   //Max number of elements the vector can hold
	  Misura* elem;   //Pointer to the first element of the vector
};

#endif
