#include "../include/MyVector.h"

//Constructors
MyVector::MyVector(int s): v_size{s}, elem{new Misura[s]}, capacity{s} {
  if(s==0){
    delete[] elem;
    elem = nullptr;
  }
  else for(int i=0;i<s;i++) elem[i]= Misura();
};

/*MyVector::MyVector(initializer_list<Misura> lst): v_size{list.v_size()},elem{new Misura[v_size]},capacity{list.v_size()} {
  std::copy(lst.begin(),lst.end(),elem);
}*/

//Costruttore di copia
MyVector::MyVector(const MyVector& arg): v_size{arg.v_size}, elem{new Misura[v_size]},capacity{arg.v_size}{
  std::copy(arg.elem,arg.elem+v_size,elem);
}

//Costruttore di spostamento
MyVector::MyVector(MyVector&& a): v_size{a.v_size}, elem{a.elem}, capacity{a.capacity} {
  a.v_size = 0;
  a.elem = nullptr;
}

//Distruttore
MyVector::~MyVector(){ delete[] elem; };

//Metodi
int MyVector::size() const{ return v_size; };

//Assegnazione
MyVector& MyVector::operator=(const MyVector& a){
  Misura* p = new Misura[a.v_size];
  std::copy(a.elem,a.elem+v_size,p);
  delete[] elem;
  elem = p;

  capacity = a.v_size;
  v_size = a.v_size;
  return *this;
}
MyVector& MyVector::operator=(MyVector&& a){
  delete[] elem;
  elem = a.elem;
  v_size = a.v_size;
  capacity = a.capacity;
  a.elem = nullptr;
  a.v_size = 0;
  return *this;
}

//Accesso
const Misura& MyVector::operator[](int i) const{
  return elem[i];
};
Misura& MyVector::operator[](int i){
  return elem[i];
};
const Misura& MyVector::at(int i) const{
  if(i<0 || i>= v_size) throw std::out_of_range("Array index out of bounds");
  return elem[i];
};
Misura& MyVector::at(int i){
  if(i<0 || i>= v_size) throw std::out_of_range("Array index out of bounds");
  return elem[i];
};

// Modifica degli elementi
void MyVector::push_back(Misura d){
  if(elem == nullptr || v_size>=capacity) reserve(v_size*2+1);
  elem[v_size++] = d;
};
void MyVector::pop_back(){
  if(v_size>0) v_size--;
}

//
void MyVector::reserve(int n) {
  //Guards
  if( n<=capacity ) return;
  if(elem == nullptr){
    elem = new Misura[n];
    capacity = n;
    v_size = n;
    return;
  }

  //Create new memory buffer
  capacity=n;
  Misura* prevVec = elem;
  elem = new Misura[n];
  std::copy(prevVec,prevVec+v_size,elem);
  delete[] prevVec;
};

