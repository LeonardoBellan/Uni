#include <iostream>
#include "../include/InertialDriver.h"
#include "../include/Misura.h"

using namespace std;

void crea_dati_finti(double m[17][6], double valore_base) {
    for(int i = 0; i < 17; i++) {
        for(int j = 0; j < 6; j++) {
            m[i][j] = valore_base + (i * 0.01) + (j * 0.001);
        }
    }
}

int main() {
    try {
        cout << "TEST 1: Inizializzazione Driver" << endl;
        InertialDriver defaultDriver;

        int dim_buffer = 3;
        InertialDriver driver(dim_buffer); 

        cout << "Driver creato con buffer di dimensione: " << dim_buffer << endl << endl;


        cout << "TEST 2: Push Back (Riempimento Buffer)" << endl;
        double dati1[17][6];
        double dati2[17][6];
        double dati3[17][6];
        double dati4[17][6]; 

        crea_dati_finti(dati1, 10.0); 
        crea_dati_finti(dati2, 20.0); 
        crea_dati_finti(dati3, 30.0);
        crea_dati_finti(dati4, 40.0);

        driver.push_back(dati1);
        cout << "Inserita Misura 1 (base 10.0)" << endl;
        driver.push_back(dati2);
        cout << "Inserita Misura 2 (base 20.0)" << endl;
        driver.push_back(dati3);
        cout << "Inserita Misura 3 (base 30.0)" << endl;

        cout << "\n--- Verifica operatore << (Ultima misura inserita: 3) ---" << endl;
        cout << driver << endl; 


        cout << "TEST 3: Buffer Circolare (Sovrascrittura)" << endl;
        driver.push_back(dati4);
        cout << "Inserita Misura 4 (base 40.0) -> Dovrebbe aver sovrascritto la Misura 1" << endl;

        cout << "\nTEST 4: get_reading (Lettura specifica)" << endl;
        std::array<double, 6> lettura = driver.get_reading(0);
        cout << "Lettura sensore 0 dell'ultima misura: [ ";
        for(auto val : lettura) cout << val << " ";
        cout << "]" << endl;

        cout << "\nTEST 5: Pop Front (Estrazione)" << endl;
        
        auto vecchia = driver.pop_front();
        cout << "Pop eseguito. Misura estratta (dovrebbe essere base 20.0):" << endl;
        cout << "Sensore 0 valore: " << vecchia[0][0] << " (Atteso: 20.0)" << endl;

        vecchia = driver.pop_front();
        cout << "Pop eseguito. Misura estratta (dovrebbe essere base 30.0):" << endl;
        cout << "Sensore 0 valore: " << vecchia[0][0] << " (Atteso: 30.0)" << endl;


        cout << "\nTEST 6: Clear Buffer" << endl;
        driver.clear_buffer();
        cout << "Buffer pulito." << endl;


        cout << "\nTEST 7: Gestione Eccezioni" << endl;
        cout << "Provo a fare pop su buffer vuoto " << endl;
        driver.pop_front();

    } catch (InertialDriver::EmptyBufferException& e) {
        cout << "EmptyBufferException" << endl;
    } catch (std::exception& e) {
        cout << "Altra eccezione: " << e.what() << endl;
    }

    return 0;
}

