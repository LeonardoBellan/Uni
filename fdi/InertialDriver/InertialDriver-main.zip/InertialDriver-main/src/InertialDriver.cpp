#include "../include/InertialDriver.h"

InertialDriver::InertialDriver() : 
    buffer(BUFFER_DIM), 
    front(0), 
    back(0), 
    numero_misure(0)
{}

InertialDriver::InertialDriver(const int buff_dim) : 
    BUFFER_DIM(buff_dim), 
    buffer(buff_dim), 
    front(0), 
    back(0), 
    numero_misure(0)
{}

void InertialDriver::push_back(const double misura[17][6])
{
    Misura m(misura);

    if( numero_misure == BUFFER_DIM ) {            //Se coda piena elimina l'elemento più vecchio
        front = (front+1)%BUFFER_DIM;
    }else {
        numero_misure++;
    }

    buffer[back] = m;             //Inserisci nuova misura (buffer[back] per definizione è vuoto)
    back = (back+1)%BUFFER_DIM;   //Aumenta indice
}


std::array<std::array<double,6>,17> InertialDriver::pop_front()
{
    if(numero_misure == 0)    
    throw EmptyBufferException();
  
    numero_misure--;
    std::array<std::array<double,6>,17> m; 

    std::array<double, 6> arr;
    
    for(int i = 0; i < 17; i++)
    {
        arr = buffer[front].get_lettura(i);

        for(int j = 0; j < 6; j++)
        {
            m[i][j] = arr[j];
        }
    }

    front = (front+1)%BUFFER_DIM;          
    return m;
}

void InertialDriver::clear_buffer()
{
    front = 0;
    back = 0;
    numero_misure = 0;
}

std::array<double,6> InertialDriver::get_reading(int n)
{
    if(numero_misure == 0)
      throw EmptyBufferException();

    int i = (back-1 + BUFFER_DIM)%BUFFER_DIM;
    return buffer[i].get_lettura(n);
}

std::ostream& operator<<(std::ostream& os, const InertialDriver& driver)
{
    if(driver.numero_misure == 0)
    {
        return os << "Buffer vuoto";
    }
    int i = (driver.back - 1 + driver.BUFFER_DIM) % driver.BUFFER_DIM;
    os << driver.buffer[i];
    return os;
}