#include "../include/Misura.h"

Misura::Misura(const double lett[17][6]){
        for(int i = 0;i < 17; i++){
            for(int j = 0; j < 6; j++){
                letture[i][j]=lett[i][j];
            }
        }
}
    //costruttore copia
Misura::Misura(const Misura& m){
        for(int i = 0; i < 17; i++){
            for(int j = 0; j < 6; j++){
                letture[i][j] = m.letture[i][j];
            }
        }
}

    // Operatore di copia
Misura& Misura::operator=(const Misura& m){
    if(this != &m) {
        for(int i = 0; i < 17; i++){
            for(int j = 0; j < 6; j++){
                letture[i][j] = m.letture[i][j];
            }
        }
        return *this;
    }
    return *this;
}
    // operatore = di spostamento
Misura& Misura::operator=(Misura&& m){
        if(this != &m) {
            for(int i = 0; i < 17; i++){
                for(int j = 0; j < 6; j++){
                    letture[i][j] = m.letture[i][j];
                }
            }
            return *this;
        }
        return *this;
}

std::array<double,6> Misura::get_lettura(int i) const{
        if(i < 0 || i >=17){
            std::cout<<"Indice non valido";
        }
        return letture[i];
}

std::array<std::array<double,6>,17> Misura::get_misura() const{
    std::array<std::array<double,6>,17> mis;
    for(int i=0;i<letture.size();i++){
        mis[i] = get_lettura(i);
    }
    return mis;
}

    //toString
std::string Misura:: toString() const{
        std::ostringstream s;

        s << "{ ";
        for(int i = 0; i<letture.size(); i++){

            s << "[ yaw_v: " << letture[i][0] << ", yaw_a: " << letture[i][1];
            s << ", pitch_v: " << letture[i][2] << ", pitch_a: " << letture[i][3];
            s << ", roll_v: " << letture[i][4] << ", roll_a: " << letture[i][5] << "],\n";
        }
        s << "}";
        return s.str();
}
    //orverload operatore <<
std::ostream& operator<<(std::ostream& os, const Misura& m){
        return os << m.toString();
}
    //overload operatore >>
std::istream& operator>>(std::istream& is, Misura& m){
        for(int i = 0;i < 17; i++){
            for(int j = 0; j < 6; j++){
                is >> m.letture[i][j];
            }
        }
        return is;
};